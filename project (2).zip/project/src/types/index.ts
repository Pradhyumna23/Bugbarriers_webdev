export interface User {
  id: string;
  email: string;
  name: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}

export interface Hotel {
  id: string;
  name: string;
  location: string;
  price: number;
  rating: number;
  image: string;
}

export interface Flight {
  id: string;
  from: string;
  to: string;
  departure: string;
  arrival: string;
  price: number;
  airline: string;
}

export interface Restaurant {
  id: string;
  name: string;
  cuisine: string;
  rating: number;
  price: string;
  image: string;
  location: string;
}