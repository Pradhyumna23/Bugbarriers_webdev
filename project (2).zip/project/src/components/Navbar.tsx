import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Plane, Hotel, UtensilsCrossed, LogOut, User, Moon, Sun } from 'lucide-react';

export default function Navbar({ toggleDarkMode, darkMode }: { toggleDarkMode: () => void, darkMode: boolean }) {
  const { isAuthenticated, logout, user } = useAuth();

  return (
    <nav className="bg-white shadow-lg dark:bg-gray-800 dark:text-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between h-16">
          <div className="flex">
            <Link to="/" className="flex items-center">
              <Plane className="h-8 w-8 text-blue-600" />
              <span className="ml-2 font-bold text-xl text-gray-800 dark:text-white">TravelHub</span>
            </Link>
          </div>

          <div className="flex items-center space-x-4">
            {isAuthenticated ? (
              <>
                <Link to="/flights" className="flex items-center text-gray-700 hover:text-blue-600 dark:text-white dark:hover:text-blue-400">
                  <Plane className="h-5 w-5 mr-1" />
                  <span>Travel Option</span>
                </Link>
                <Link to="/hotels" className="flex items-center text-gray-700 hover:text-blue-600 dark:text-white dark:hover:text-blue-400">
                  <Hotel className="h-5 w-5 mr-1" />
                  <span>Hotels</span>
                </Link>
                <Link to="/restaurants" className="flex items-center text-gray-700 hover:text-blue-600 dark:text-white dark:hover:text-blue-400">
                  <UtensilsCrossed className="h-5 w-5 mr-1" />
                  <span>Restaurants</span>
                </Link>
                <div className="flex items-center space-x-2">
                  <User className="h-5 w-5 text-gray-600 dark:text-white" />
                  <span className="text-gray-700 dark:text-white">{user?.name}</span>
                </div>
                <button
                  onClick={logout}
                  className="flex items-center text-gray-700 hover:text-red-600 dark:text-white dark:hover:text-red-400"
                >
                  <LogOut className="h-5 w-5" />
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/login"
                  className="text-gray-700 hover:text-blue-600 dark:text-white dark:hover:text-blue-400 px-3 py-2 rounded-md"
                >
                  Login
                </Link>
                <Link
                  to="/signup"
                  className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600"
                >
                  Sign Up
                </Link>
              </>
            )}

            {/* Dark mode toggle */}
            <button
              onClick={toggleDarkMode}
              className="p-2 text-gray-700 dark:text-white"
            >
              {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
