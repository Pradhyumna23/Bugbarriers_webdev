import React, { useState, useEffect } from 'react';
import { Moon, Sun } from 'lucide-react'; // Optional icons for toggling

export default function DarkModeToggle() {
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Check if dark mode preference exists in localStorage
  useEffect(() => {
    const storedPreference = localStorage.getItem('darkMode');
    if (storedPreference) {
      setIsDarkMode(storedPreference === 'true');
    } else {
      setIsDarkMode(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
    }
  }, []);

  // Toggle dark mode and save the preference
  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    localStorage.setItem('darkMode', !isDarkMode ? 'true' : 'false');
    document.documentElement.classList.toggle('dark', !isDarkMode); // Toggle the 'dark' class
  };

  return (
    <button
      onClick={toggleDarkMode}
      className="p-2 rounded-md text-gray-800 dark:text-white focus:outline-none"
    >
      {isDarkMode ? (
        <Sun className="h-6 w-6" />
      ) : (
        <Moon className="h-6 w-6" />
      )}
    </button>
  );
}
