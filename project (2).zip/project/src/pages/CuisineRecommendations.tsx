import React from 'react';
import { useParams } from 'react-router-dom';

const recommendations: Record<string, { name: string; image: string }[]> = {
  'North Indian': [
    { name: 'Butter Chicken', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQWr-YP263Cl5I5f5a0G4RsqdFfHpBCO2u-uQ&s' },
    { name: 'Dal Makhani', image: 'https://sinfullyspicy.com/wp-content/uploads/2015/03/1200-by-1200-images-1-500x500.jpg' },
    { name: 'Paneer Tikka', image: 'https://sharethespice.com/wp-content/uploads/2024/02/Paneer-Tikka-Featured.jpg' },
  ],
  Seafood: [
    { name: 'Grilled Lobster', image: 'https://www.allrecipes.com/thmb/vGenjPjJOsBVVpTG_iUbfjyu2Pw=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/36996-Grilled-Rock-Lobsters-109-4x3-fb4e7e3c2ea34a5b8de9caf3697ed5b9.jpg' },
    { name: 'Prawn Curry', image: 'https://getfish.com.au/cdn/shop/articles/Sri_Lankan_Fish_Prawn_Curry_ed587de9-f895-43d3-8161-ef2ce8b94236.png?v=1714542637' },
    { name: 'Fish Tikka', image: 'https://vismaifood.com/storage/app/uploads/public/daa/96d/7bc/thumb__1200_0_0_0_auto.jpg' },
  ],
  'South Indian': [
    { name: 'Masala Dosa', image: 'https://www.indianhealthyrecipes.com/wp-content/uploads/2021/06/masala-dosa-recipe.jpg' },
    { name: 'Idli Sambar', image: 'https://sapanarestaurant.com/wp-content/uploads/2019/11/idli-sambar-900x600.jpg' },
    { name: 'Prawn Sukka', image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQoQAdQdh6QYkrVGAWXvdAWUzOzYdSfH24tCw&s' },
  ],
  'Modern Indian': [
    { name: ' Biryani', image: 'https://static.india.com/wp-content/uploads/2018/08/Biryani-main1.jpg?impolicy=Medium_Resize&w=1200&h=800' },
    { name: 'Sev Chaat', image: 'https://i.ytimg.com/vi/_o3EBtK3MSY/maxresdefault.jpg' },
    { name: 'Tandoori Broccoli', image: 'https://www.indianveggiedelight.com/wp-content/uploads/2021/07/air-fryer-tandoori-broccoli-featured.jpg' },
  ],
};

const cuisineImages: Record<string, string> = {
  'North Indian': 'https://example.com/north-indian.jpg',
  Seafood: 'https://example.com/seafood.jpg',
  'South Indian': 'https://example.com/south-indian.jpg',
  'Modern Indian': 'https://example.com/modern-indian.jpg',
};

export default function CuisineRecommendations() {
  const { cuisine } = useParams<{ cuisine: string }>();
  const dishes = cuisine ? recommendations[cuisine] : [];
  const cuisineImage = cuisine ? cuisineImages[cuisine] : null;

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-gray-900">
        Recommended Dishes for {cuisine}
      </h1>
      
      {/* Render cuisine image if available */}
      {cuisineImage && (
        <div className="mt-4">
          <img
            src={cuisineImage}
            alt={`${cuisine} cuisine`}
            className="w-full h-auto object-cover rounded-lg"
          />
        </div>
      )}
      
      {dishes && dishes.length > 0 ? (
        <ul className="mt-6 grid gap-4">
          {dishes.map((dish, index) => (
            <li
              key={index}
              className="bg-white shadow-md rounded-lg p-4 text-gray-800 text-lg font-medium"
            >
              <div className="flex items-center">
                <img
                  src={dish.image}
                  alt={dish.name}
                  className="w-16 h-16 object-cover rounded-md"
                />
                <span className="ml-4">{dish.name}</span>
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <p className="mt-4 text-gray-600">No recommendations available for this cuisine.</p>
      )}
    </div>
  );
}
