import React from 'react';
import { Link } from 'react-router-dom';
import { Plane, Hotel, UtensilsCrossed } from 'lucide-react';

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="relative">
        <div className="absolute inset-0">
          <img
            className="w-full h-[600px] object-cover"
            src="https://media.licdn.com/dms/image/v2/D5622AQFOxq0gTT-DtQ/feedshare-shrink_800/feedshare-shrink_800/0/1715217702977?e=2147483647&v=beta&t=wtOmV0pIhvb3P4zaMyAO9kHwlFt7dufeNmFabwgaxfo"
            alt="Travel"
          />
          <div className="absolute inset-0 bg-gray-900 opacity-50"></div>
        </div>

        <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
            Your Journey Begins Here
          </h1>
          <p className="mt-6 text-xl text-gray-300 max-w-3xl">
            Discover amazing destinations, Cuisine recommendation , find perfect hotels, and explore local restaurants near you.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
          <Link
            to="/flights"
            className="relative group bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
          >
            <div className="flex items-center">
              <Plane className="h-8 w-8 text-blue-600" />
              <h3 className="ml-3 text-xl font-semibold text-gray-900">Transportation Travel Booking</h3>
            </div>
            <p className="mt-4 text-gray-500">Find and book the best flights,trains and bus to your destination.</p>
          </Link>

          <Link
            to="/hotels"
            className="relative group bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
          >
            <div className="flex items-center">
              <Hotel className="h-8 w-8 text-blue-600" />
              <h3 className="ml-3 text-xl font-semibold text-gray-900">Find Hotels</h3>
            </div>
            <p className="mt-4 text-gray-500">Discover comfortable stays at the best prices.</p>
          </Link>

          <Link
            to="/restaurants"
            className="relative group bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
          >
            <div className="flex items-center">
              <UtensilsCrossed className="h-8 w-8 text-blue-600" />
              <h3 className="ml-3 text-xl font-semibold text-gray-900">Explore Restaurants</h3>
            </div>
            <p className="mt-4 text-gray-500">Find the best local restaurants and cuisines.</p>
          </Link>
        </div>
      </div>
    </div>
  );
}