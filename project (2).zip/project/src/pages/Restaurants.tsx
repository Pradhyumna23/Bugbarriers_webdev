import React, { useState } from 'react';
import { UtensilsCrossed, Star } from 'lucide-react';
import SearchBar from '../components/SearchBar';
import { useNavigate } from 'react-router-dom'; // Make sure this import is included
import { Restaurant } from '../types';

export default function Restaurants() {
  const navigate = useNavigate();
  const [restaurants] = useState([
    {
      id: '1',
      name: 'Bukhara',
      cuisine: 'North Indian',
      rating: 4.8,
      price: 'Rs',
      location: 'ITC Maurya, New Delhi',
      image: 'https://dynamic-media-cdn.tripadvisor.com/media/photo-o/1b/2d/2f/94/karavalli-garden.jpg?w=600&h=-1&s=1'
    },
    {
      id: '2',
      name: 'Trishna',
      cuisine: 'Seafood',
      rating: 4.7,
      price: 'Rs',
      location: 'Fort, Mumbai',
      image: 'https://hotelsabovepar.com/wp-content/uploads/2024/07/image-38-2-1024x683.jpg'
    },
    {
      id: '3',
      name: 'Karavalli',
      cuisine: 'South Indian Coastal',
      rating: 4.6,
      price: 'Rs',
      location: 'The Gateway Hotel, Bengaluru',
      image: 'https://content.jdmagicbox.com/v2/comp/bangalore/n8/080pxx80.xx80.110304102607.n7n8/catalogue/altaf-chillies-restaurant-cooke-town-bangalore-home-delivery-restaurants-12s79c7.jpg'
    },
    {
      id: '4',
      name: 'Indian Accent',
      cuisine: 'Modern Indian',
      rating: 4.9,
      price: 'Rs',
      location: 'The Lodhi, New Delhi',
      image: 'https://rishikeshcamps.in/wp-content/uploads/2023/05/restaarant.jpg'
    },
    {
      id: '5',
      name: 'Dakshin',
      cuisine: 'South Indian',
      rating: 4.7,
      price: 'Rs',
      location: 'ITC Grand Chola, Chennai',
      image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR8ZHcA-sbBn_xS7iUVWtsHrygj8ASsfEZ_Og&s'
    }
  ]);
  
  const [searchQuery, setSearchQuery] = useState('');

  const filteredRestaurants = restaurants.filter(restaurant =>
    restaurant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    restaurant.cuisine.toLowerCase().includes(searchQuery.toLowerCase()) ||
    restaurant.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleReserve = (cuisine: string) => {
    // Navigate to the cuisine recommendations page with the selected cuisine
    navigate(`/recommendations/${cuisine}`);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-yellow-900">Popular Restaurants</h1>
        <div className="w-96">
          <SearchBar placeholder="Search restaurants..." onSearch={setSearchQuery} />
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredRestaurants.map((restaurant) => (
          <div key={restaurant.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="relative h-48">
              <img
                src={restaurant.image}
                alt={restaurant.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <UtensilsCrossed className="h-5 w-5 text-blue-600" />
                  <h3 className="ml-2 text-lg font-semibold text-gray-900">{restaurant.name}</h3>
                </div>
                <div className="flex items-center">
                  <Star className="h-5 w-5 text-yellow-400 fill-current" />
                  <span className="ml-1 text-gray-600">{restaurant.rating}</span>
                </div>
              </div>
              <div className="mt-2 flex items-center justify-between">
                <p className="text-gray-500">{restaurant.cuisine}</p>
                <p className="text-gray-600">{restaurant.price}</p>
              </div>
              <p className="mt-2 text-gray-500">{restaurant.location}</p>
              <div className="mt-4 flex justify-end">
                <button
                  className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
                  onClick={() => handleReserve(restaurant.cuisine)} // Pass cuisine to the handler
                >
                  Reserve Table
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}