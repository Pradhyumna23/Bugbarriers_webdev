import React, { useState } from 'react';
import { format } from 'date-fns';
import { Plane, Train, Bus } from 'lucide-react';
import SearchBar from '../components/SearchBar';

export default function TravelOptions() {
  const [flights] = useState([
    { id: '1', from: 'Delhi (DEL)', to: 'Mumbai (BOM)', departure: '2024-03-20T10:00:00', arrival: '2024-03-20T12:15:00', price: 4500, airline: 'IndiGo' },
    { id: '2', from: 'Bengaluru (BLR)', to: 'Hyderabad (HYD)', departure: '2024-03-21T14:30:00', arrival: '2024-03-21T15:45:00', price: 3500, airline: 'SpiceJet' },
    { id: '3', from: 'Chennai (MAA)', to: 'Kolkata (CCU)', departure: '2024-03-22T08:00:00', arrival: '2024-03-22T10:30:00', price: 5000, airline: 'Air India' },
    { id: '4', from: 'Kochi (COK)', to: 'Thiruvananthapuram (TRV)', departure: '2024-03-25T19:00:00', arrival: '2024-03-25T19:45:00', price: 2000, airline: 'Alliance Air' },
  ]);

  const [trains] = useState([
    { id: '1', from: 'Delhi', to: 'Mumbai', departure: '2024-03-20T08:00:00', arrival: '2024-03-20T20:00:00', price: 1500, train: 'Rajdhani Express' },
    { id: '2', from: 'Bengaluru', to: 'Chennai', departure: '2024-03-21T06:00:00', arrival: '2024-03-21T12:00:00', price: 700, train: 'Shatabdi Express' },
    { id: '3', from: 'Ahmedabad', to: 'Jaipur', departure: '2024-03-23T07:00:00', arrival: '2024-03-23T15:00:00', price: 1200, train: 'Superfast Express' },
    { id: '4', from: 'Kolkata', to: 'Patna', departure: '2024-03-24T09:00:00', arrival: '2024-03-24T18:00:00', price: 1000, train: 'Garib Rath' },
  ]);

  const [buses] = useState([
    { id: '1', from: 'Delhi', to: 'Agra', departure: '2024-03-20T07:00:00', arrival: '2024-03-20T11:00:00', price: 500, operator: 'Volvo' },
    { id: '2', from: 'Mumbai', to: 'Pune', departure: '2024-03-21T09:00:00', arrival: '2024-03-21T12:30:00', price: 600, operator: 'Shivneri' },
    { id: '3', from: 'Chennai', to: 'Bengaluru', departure: '2024-03-22T14:00:00', arrival: '2024-03-22T18:30:00', price: 800, operator: 'KSRTC' },
    { id: '4', from: 'Hyderabad', to: 'Vijayawada', departure: '2024-03-23T16:00:00', arrival: '2024-03-23T20:00:00', price: 400, operator: 'APSRTC' },
  ]);

  const [searchQuery, setSearchQuery] = useState('');

  const filterBySearch = (data) =>
    data.filter(
      (item) =>
        item.from.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.to.toLowerCase().includes(searchQuery.toLowerCase())
    );

  const renderOptions = (title, data, icon, color, transportType) => {
    const filteredData = filterBySearch(data);

    return (
      <div>
        <h2 className="text-2xl font-semibold text-yellow-800 mt-8 mb-4">{title}</h2>
        {filteredData.length > 0 ? (
          <div className="grid gap-6">
            {filteredData.map((item) => (
              <div key={item.id} className="bg-white rounded-lg shadow-md p-6">
                <div className="flex items-center space-x-4">
                  {React.createElement(icon, { className: `h-6 w-6 ${color}` })}
                  <div>
                    <h3 className="text-purple-600 font-semibold">
                      {transportType === 'bus' ? item.operator : transportType === 'flight' ? item.airline : item.train}
                    </h3>
                    <p className="text-gray-500">{item.from} → {item.to}</p>
                    <p className="text-gray-600">
                      Departure: {format(new Date(item.departure), 'MMM d, yyyy h:mm a')}
                    </p>
                    <p className="text-gray-600">
                      Arrival: {format(new Date(item.arrival), 'MMM d, yyyy h:mm a')}
                    </p>
                    <p className={`font-bold ${color}`}>₹{item.price}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-yellow-500">No results found for "{searchQuery}"</p>
        )}
      </div>
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-yellow-900">Travel Options</h1>
        <div className="w-96">
          <SearchBar placeholder="Search..." onSearch={setSearchQuery} />
        </div>
      </div>
      {renderOptions('Flights', flights, Plane, 'text-blue-600', 'flight')}
      {renderOptions('Trains', trains, Train, 'text-green-600', 'train')}
      {renderOptions('Buses', buses, Bus, 'text-red-600', 'bus')}
    </div>
  );
}
