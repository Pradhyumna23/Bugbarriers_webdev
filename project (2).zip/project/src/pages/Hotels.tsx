import React, { useState } from 'react';
import { Hotel as HotelIcon, Star } from 'lucide-react';
import SearchBar from '../components/SearchBar';
import { useNavigate } from 'react-router-dom';

export default function Hotels() {
  const [hotels] = useState([
    {
      id: '1',
      name: 'The Oberoi Udaivilas',
      location: 'Udaipur, Rajasthan',
      price: 450,
      rating: 4.9,
      image: 'https://www.momondo.in/himg/44/e1/6e/leonardo-56498-150580096-217999.jpg'
    },
    {
      id: '2',
      name: 'Taj Mahal Palace',
      location: 'Mumbai, Maharashtra',
      price: 400,
      rating: 4.8,
      image: 'https://content.jdmagicbox.com/v2/comp/bangalore/z6/080pxx80.xx80.230128023819.e6z6/catalogue/la-serene-hotels-rachenahalli-bangalore-0umsg1twu9-250.jpg'
    },
    {
      id: '3',
      name: 'The Leela Palace',
      location: 'Bengaluru, Karnataka',
      price: 350,
      rating: 4.7,
      image: 'https://pix10.agoda.net/hotelImages/30444756/0/886ca5127f81d7b22676dbe45ca49827.jpg?ca=26&ce=0&s=702x392'
    },
    {
      id: '4',
      name: 'Rambagh Palace',
      location: 'Jaipur, Rajasthan',
      price: 500,
      rating: 4.9,
      image: 'https://www.luxuryabode.com/mona/img/hotels.jpg'
    },
    {
      id: '5',
      name: 'ITC Grand Chola',
      location: 'Chennai, Tamil Nadu',
      price: 320,
      rating: 4.6,
      image: 'https://dynamic-media-cdn.tripadvisor.com/media/photo-o/2c/21/20/c9/facadenight.jpg?w=1200&h=-1&s=1'
    }
  ]);
  
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  const filteredHotels = hotels.filter((hotel) =>
    hotel.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    hotel.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleReserveClick = (hotelId: string) => {
    navigate(`/hotel/${hotelId}`);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-yellow-900">Popular Hotels</h1>
        <div className="w-96">
          <SearchBar placeholder="Search hotels..." onSearch={setSearchQuery} />
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredHotels.map((hotel) => (
          <div key={hotel.id} className="bg-white rounded-lg shadow-md overflow-hidden dark:bg-gray-800 dark:text-white">
            <div className="relative h-48">
              <img
                src={hotel.image}
                alt={hotel.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <HotelIcon className="h-5 w-5 text-blue-600" />
                  <h3 className="ml-2 text-lg font-semibold text-gray-900 dark:text-white">{hotel.name}</h3>
                </div>
                <div className="flex items-center">
                  <Star className="h-5 w-5 text-yellow-400 fill-current" />
                  <span className="ml-1 text-gray-600 dark:text-white">{hotel.rating}</span>
                </div>
              </div>
              <div className="mt-2 flex items-center justify-between">
                <p className="text-gray-500 dark:text-white">{hotel.location}</p>
                <p className="text-gray-600 dark:text-white">{`$${hotel.price} / night`}</p>
              </div>
              <div className="mt-4 flex justify-end">
                <button
                  className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-600"
                  onClick={() => handleReserveClick(hotel.id)}
                >
                  Book Now
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
