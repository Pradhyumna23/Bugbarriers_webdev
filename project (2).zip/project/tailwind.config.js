/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class', // Enable dark mode using the 'class' strategy
  theme: {
    extend: {
      colors: {
        'primary-light': '#3490dc', // Light theme primary color
        'primary-dark': '#1e3a8a',  // Dark theme primary color
        'bg-light': '#f9fafb',      // Light background color
        'bg-dark': '#1f2937',       // Dark background color
        'text-light': '#374151',    // Light text color
        'text-dark': '#e5e7eb',     // Dark text color
        'accent-light': '#ff6363',  // Accent color for light mode
        'accent-dark': '#ff4f58',   // Accent color for dark mode
      },
      fontFamily: {
        sans: ['Inter', 'Arial', 'sans-serif'], // Custom font family
      },
      transitionProperty: {
        'bg-color': 'background-color',  // Smooth background color transition
        'text-color': 'color',            // Smooth text color transition
        'border-color': 'border-color',   // Smooth border color transition
      },
    },
  },
  plugins: [],
};
